<p align="center">
  <img src="docs/folio-logo.svg" width="104" alt="Folio logo" />
</p>

<h1 align="center">Folio</h1>

<p align="center">
  A quiet, local-first personal finance app for Android.<br/>
  Track money, recurring cash flow, investments, budgets, history and long-term progress without turning your finances into a brokerage dashboard.
</p>

<p align="center">
  <strong>Android · Kotlin · Jetpack Compose · Nothing-inspired</strong>
</p>

<p align="center">
  <img src="docs/design-direction.png" width="820" alt="Folio Android design direction" />
</p>

## About

Folio is a personal finance tracker, not a broker. It does not place trades, hold funds, or execute orders. The app is designed around a small number of calm views: net worth, monthly flow, expenses, recurring money, investments and progress over time.

Folio Android is the primary Folio product. It is self-contained and does not require a Folio website or account.

## Highlights

| Area | What Folio does |
| --- | --- |
| Home | Net worth, real history, monthly flow, upcoming money, emergency-fund coverage and recent transactions |
| Expenses | Monthly expenses, categories and minimal per-category budgets |
| Recurring | Salary/income, bills and recurring investments with month-aware completion |
| Investments | ISIN lookup, manual assets, purchase dates, units, cost basis, market value, gain/loss and contribution history |
| History | Transaction timeline, Monthly Overview, Net-worth History and investment price charts |
| Long term | Annual Review, Projected Growth, milestones and contribution streaks |
| Personal context | Investment tags and notes, including CS2-case tracking |
| Privacy | Optional biometric/device-credential lock and local-first storage |
| Android | 3×1 balance widget, system theme, edge-to-edge Compose UI and GitHub beta updater |

## Investments

For exchange-traded instruments, Folio can start with an ISIN:

```text
ISIN → OpenFIGI → matching listings → choose the listing → save holding
```

Supported tracked types include ETF, stock, fund, bond, index, CS2 and other manual assets.

Folio stores contributions separately from market prices. When you provide units/shares and Folio has a market price, it can show:

```text
Current value
Cost basis
Unrealized gain / loss
Units
Price history
Purchase markers
Price source + last refresh
```

Market data is informational only. There are no Buy or Sell controls.

## Money history

Folio builds history from your own actions rather than demo data. A fresh install starts empty.

The local ledger records salary, bills and investments by month. Expenses and investment transactions retain their dates, which powers:

- Transaction Timeline
- Monthly Overview and month-over-month comparison
- Annual Review
- Net-worth History
- Investment contribution streaks
- Emergency-fund coverage
- Automatic milestones

## Data sources

- **OpenFIGI v3** — ISIN-to-instrument/listing resolution.
- **Yahoo Finance public chart/search endpoints** — cached historical market-price data used by the beta app.

No GitHub token, broker password or financial account credential is embedded in the APK.

## Local-first data

Beta data is stored locally with SharedPreferences + JSON while the model is still evolving. Folio does not require Folio Web or a Folio cloud account.

The data model is intentionally migration-friendly: older beta records remain readable when newer fields such as units, price-source metadata, tags or notes are missing.

## Design

Folio follows a restrained visual system:

- warm off-white light surfaces and near-black dark surfaces
- large numbers, thin separators and generous whitespace
- monochrome category glyphs
- restrained gain/loss color
- stable bottom-navigation geometry
- no brokerage-style cards, trade tickets or dense market dashboards

## Beta releases

Versioning is standardized across PIX projects:

```text
v0.5.0.beta   # beta
v0.5.1.beta   # next beta/fix
v0.5.0        # stable
v1.0.0        # major stable
```

`CHANGELOG.md` is the source of truth for release notes. When a beta tag is pushed, GitHub Actions extracts that version's **Added / Changed / Fixed** section, publishes it on the GitHub release and the in-app updater shows the same notes before downloading/installing the APK.

### Publish a beta

```bash
git tag -a v0.5.0.beta -m "Folio v0.5.0.beta"
git push origin v0.5.0.beta
```

The release workflow:

1. validates the repository
2. compiles BetaDebug and PlayDebug
3. restores the signing key from GitHub Actions secrets
4. builds and verifies the signed beta APK
5. generates a SHA-256 checksum
6. extracts the matching `CHANGELOG.md` section
7. publishes the APK, checksum and structured release notes

## Build locally

Requirements:

- JDK 17
- Android SDK / API 37
- Gradle 9.4.1

```bash
gradle :app:assembleBetaDebug :app:assemblePlayDebug
```

Beta debug output:

```text
app/build/outputs/apk/beta/debug/app-beta-debug.apk
```

## Beta signing

Never commit signing files or their Base64 representation. Keep the beta signing key private and configure these GitHub Actions secrets:

```text
FOLIO_BETA_KEYSTORE_BASE64
FOLIO_BETA_KEYSTORE_PASSWORD
FOLIO_BETA_KEY_ALIAS
FOLIO_BETA_KEY_PASSWORD
```

The same signing key must be retained for future updates to an already-installed beta package.

## Project structure

```text
app/src/main/                       main Android app
app/src/beta/                       GitHub beta updater + beta manifest
app/src/play/                       Play distribution behavior
app/src/main/java/com/pix/folio/
  data/                             persistence, ISIN and price services
  model/                            Folio financial model
  ui/                               Compose app and ViewModel
  widget/                           Glance widget
.github/workflows/build-apk.yml     CI + signed beta release
scripts/validate_release.py         repository/release validation
scripts/release_notes.py            changelog section extractor
CHANGELOG.md                        release-note source of truth
```

## License

MIT. See [LICENSE](LICENSE).
